# Retrieve Profile × Plan 双层约束

前四篇描述了检索管道的每个环节。现在面对一个实际问题：检索参数很多——检索模式、top_k、rrf_k、是否重排、是否 LLM 改写、多知识库上限——让每个调用方每次都手动配置这些参数，既繁琐又容易出错。

rag-center 用两层机制来处理这个复杂度：**Profile 预设**负责封装参数组合，**Plan 约束**负责平台层面的上限控制。两者分工明确，共同决定每次检索的实际行为。

## Profile：一个词代表一套策略

Profile 的核心思路是把常用的参数组合预设好，给每套组合起一个名字。调用方只需要说"我要 balanced"，系统自动展开成对应的参数集。

四个预设 profile 覆盖了从速度优先到效果优先的不同需求：

| Profile | 检索模式 | LLM 改写 | LLM 重排 | top_k | 最低套餐 |
|---|---|---|---|---|---|
| speed | 仅向量 | 关 | 关 | 3 | free |
| balanced | 混合（向量+BM25） | 关 | 关 | 5 | standard |
| quality | 混合（向量+BM25） | 开 | 开 | 8 | pro |
| custom | 自定义 | 自定义 | 自定义 | 自定义 | 当前 plan 上限 |

从 speed 到 quality，每一步都是在用更多的计算换更好的效果。这个递进关系是刻意设计的，不是随机排列：

- **speed**：只走向量检索，延迟最低，适合响应速度敏感的场景
- **balanced**：加入 BM25 混合召回，效果和成本的平衡点，适合大多数生产场景
- **quality**：再加 LLM 改写和重排，调用了两次 LLM，效果最好但成本最高

Profile 的配置集中在 `app/retrieval/profile_presets.py`，硬编码在代码里而不是数据库，理由和 Plan 配置一样——版本可控、变更走部署流程、不怕误改：

```python
# rag-center/app/retrieval/profile_presets.py

@dataclass(frozen=True)
class RetrieveProfile:
    search_mode: str      # "vector_only" | "hybrid"
    query_rewrite: bool
    rerank: bool
    top_k: int

PROFILE_PRESETS: dict[str, RetrieveProfile] = {
    "speed": RetrieveProfile(
        search_mode="vector_only",
        query_rewrite=False,
        rerank=False,
        top_k=3,
    ),
    "balanced": RetrieveProfile(
        search_mode="hybrid",
        query_rewrite=False,
        rerank=False,
        top_k=5,
    ),
    "quality": RetrieveProfile(
        search_mode="hybrid",
        query_rewrite=True,
        rerank=True,
        top_k=8,
    ),
}
```

custom 给了精细控制的空间——某个场景对精确关键词匹配特别重要，想调整 BM25 相关参数；或者文档集合很小，不需要 top_k=8，想手动设为 5 节省成本。custom 模式允许逐参数配置，但 Plan 上限同样生效，保证平台对资源消耗有最终控制权。

## Plan：平台层面的上限保障

Plan 控制的是平台对不同套餐用户的能力上限。它的作用不是限制 profile 的选择，而是**确保无论选什么 profile，实际生效的参数不超过该套餐的上限**。

比如 free 套餐用户选择 custom 并手动填入所有 quality 的参数，系统不会报错，但实际执行时会被降级——top_k 被裁到 free 上限（3），LLM 改写被关闭，重排被关闭，多知识库限制为 1 个。用户拿到的结果等同于 speed profile 的效果。

这个降级逻辑在 `retrieve_policy.py` 里执行，它是整条管道参数的唯一入口：

```python
# rag-center/app/services/retrieve_policy.py

def resolve_retrieve_params(
    profile: RetrieveProfile,
    plan: Plan,
) -> ResolvedParams:
    params = profile.to_params()  # 展开 profile 为参数字典

    # Plan 上限裁剪，无论 profile 填了什么，都不能超过套餐上限
    params.top_k = min(params.top_k, plan.max_top_k)
    params.max_kb_count = min(params.max_kb_count, plan.max_kb_count)

    if not plan.allows_rerank:
        params.rerank = False

    if not plan.allows_query_rewrite:
        params.query_rewrite = False

    if not plan.allows_hybrid_search:
        params.search_mode = "vector_only"

    return params
```

后续所有环节使用的参数都来自这里，没有任何环节绕过它直接读取请求参数。

## 两层机制的协作

Profile 和 Plan 的分工可以用一句话概括：Profile 表达调用方的意图，Plan 表达平台的约束，`retrieve_policy.py` 把两者翻译成管道实际执行的参数。

这套设计对三类角色都友好：

- **普通调用方**：选一个 profile 名字就够了，不需要了解检索内部参数，入门门槛低
- **高级调用方**：custom 模式允许逐参数配置，满足精细调整的需求，Plan 约束只是设上限，不挡路
- **平台方**：无论用户选什么，Plan 约束保证资源消耗在可接受范围内，不会有 free 用户消耗 pro 级别的资源，也不会有 standard 用户意外开启 pro 专属功能

至此，检索全链路的五个关键环节都讲完了。从查询进入系统，经过优化、双路召回、RRF 融合、可选重排，再到多知识库的并行与二次融合，最终由 Profile 和 Plan 统一约束参数——这条管道的每一个设计决策背后都有明确的动机，而不是随机堆叠的功能。
