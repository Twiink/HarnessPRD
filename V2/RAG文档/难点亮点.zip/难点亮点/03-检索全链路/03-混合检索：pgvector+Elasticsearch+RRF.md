# 混合检索：pgvector + Elasticsearch + RRF

查询优化之后，`search_query` 进入召回阶段。这是整条检索管道技术含量最集中的部分：两路异构检索并行执行，结果通过 RRF 算法融合成一个统一的排名列表。

理解这套设计，需要先搞清楚两路检索各自擅长什么、又各自缺什么。

## 向量检索与 BM25：互补而非竞争

两路检索的核心差异如下：

| | 向量检索（pgvector） | BM25 检索（Elasticsearch） |
|---|---|---|
| 核心算法 | 余弦相似度 | TF-IDF 词频统计 |
| 擅长场景 | 语义相似，措辞不同 | 关键词精确匹配 |
| 薄弱场景 | 专有名词、精确短语匹配 | 语义相关但无共同词 |
| 中文支持 | embedding 层处理 | IK 分词器（ik_smart/ik_max_word） |
| 分数量纲 | 0~1（余弦相似度） | TF-IDF 加权，无固定上界 |

**向量检索**的能力在于捕捉语义相似性。用户问"如何取消订阅"，即使文档里写的是"停止续费操作步骤"，向量检索也大概率能找到，因为两者在语义空间里距离很近。但对专有名词、产品型号、精确短语，embedding 空间的距离不能很好地反映相关性，这是它的盲区。

**BM25 检索**的能力在于关键词精确命中。Elasticsearch 加上 IK 中文分词器，能正确处理中文语境下的词语切分。但"取消订阅"和"停止续费"对 BM25 来说几乎没有关联，因为没有共同词汇。

两者不是竞争关系，是互补关系。只用其中一路，都会有系统性的盲区。混合检索的目标是取长补短，让两路召回的结果叠加起来覆盖更宽的范围。两路检索各自独立执行：

```python
# rag-center/app/services/retrieval/vector_searcher.py

async def vector_search(
    query_vector: list[float], kb_id: str, top_k: int
) -> list[Chunk]:
    sql = """
        SELECT id, content, metadata,
               1 - (embedding <=> $1::vector) AS score
        FROM chunks
        WHERE tenant_id = $2 AND kb_id = $3
        ORDER BY embedding <=> $1::vector
        LIMIT $4
    """
    rows = await db.fetch(sql, query_vector, tenant_id, kb_id, top_k)
    return [Chunk(**row) for row in rows]
```

```python
# rag-center/app/services/retrieval/es_searcher.py

async def bm25_search(
    query: str, kb_id: str, top_k: int
) -> list[Chunk]:
    body = {
        "query": {
            "bool": {
                "must": {
                    "match": {"content": {"query": query, "analyzer": "ik_smart"}}
                },
                "filter": [
                    {"term": {"tenant_id": tenant_id}},
                    {"term": {"kb_id": kb_id}},
                ],
            }
        },
        "size": top_k,
    }
    resp = await es.search(index="chunks", body=body)
    return [
        Chunk(**hit["_source"], score=hit["_score"])
        for hit in resp["hits"]["hits"]
    ]
```

租户隔离通过 `WHERE tenant_id = ?` 和 ES filter 在数据层完成，业务层不需要额外处理。

## 为什么选 RRF 而不是加权平均

两路检索各自返回一个按分数排序的列表。要把它们合并成一个最终列表，最直觉的做法是加权平均：给每路检索的分数乘以一个权重，加总之后重新排序。

这个做法有一个根本性的问题：**两路检索的分数量纲完全不同**。向量检索的分数是余弦相似度，大多数结果落在 0.7 到 0.9 之间；BM25 的分数是 TF-IDF 加权的词频统计量，没有固定上界，可能是 2.5、也可能是 50。直接把这两个分数加在一起，等于在比较两把刻度不同的尺子。权重没有理论依据，只能靠经验反复调，而且换一个业务场景就要重新调。这是脆弱的设计。

**RRF（Reciprocal Rank Fusion，倒数排名融合）解决了这个问题**。它不看原始分数，只看每路检索里文档的排名位置：

```
score(d) = Σ  1 / (k + rank_i(d))
           i
```

其中 `rank_i(d)` 是文档 d 在第 i 路检索结果中的排名（从 1 开始），`k` 是平滑系数，默认取 60。对所有检索路径求和，得到文档最终的 RRF 分数。

## RRF 的实现与数字示例

RRF 的实现本身并不复杂，关键是统一的数据结构：

```python
# rag-center/app/services/retrieval/rrf.py

def rrf_merge(
    result_lists: list[list[Chunk]],
    k: int = 60,
    top_k: int = 10,
) -> list[Chunk]:
    """
    倒数排名融合：不看原始分数，只看排名位置。
    在多路结果中同时出现的文档，得分天然更高。
    """
    scores: dict[str, float] = defaultdict(float)
    chunk_map: dict[str, Chunk] = {}

    for result_list in result_lists:
        for rank, chunk in enumerate(result_list, start=1):
            scores[chunk.id] += 1.0 / (k + rank)
            chunk_map[chunk.id] = chunk

    ranked = sorted(scores.items(), key=lambda x: x[1], reverse=True)
    return [chunk_map[cid] for cid, _ in ranked[:top_k]]
```

用一个简单例子说明 RRF 如何工作。假设有三个文档 A、B、C，向量检索和 BM25 检索各自返回了排名：

```
向量检索排名:  A(1) > B(2) > C(3)
BM25 检索排名: B(1) > C(2) > A(3)
```

代入公式（k=60）：

```
score(A) = 1/(60+1) + 1/(60+3) = 0.01639 + 0.01587 = 0.03226
score(B) = 1/(60+2) + 1/(60+1) = 0.01613 + 0.01639 = 0.03252
score(C) = 1/(60+3) + 1/(60+2) = 0.01587 + 0.01613 = 0.03200
```

最终排名：B > A > C。B 在两路检索里都排名靠前，所以最终排第一——这是符合直觉的结果。文档只在一路检索中出现时，它只能获得一路的 RRF 贡献；两路都出现的文档能获得两路加总。这意味着 RRF 天然会给**两路检索都认可**的文档更高的排名，而不是仅仅被一路以高分命中的文档。

k=60 的作用是平滑排名差异：排名第 1 和第 2 的分数差（1/61 vs 1/62）比较小，不会因为排名微小变化导致融合结果剧烈波动。这个取值是经过大量实验验证的经验值，在大多数场景下表现稳健。

最终 top_k 的截断数量由 profile 决定：speed profile 取前 3，balanced 取前 5，quality 取前 8。这个 top_k 的设置逻辑在第五篇关于 Profile 的讨论里会详细说明。

RRF 融合之后，如果当前 profile 开启了 LLM 重排，融合结果会进入重排阶段。LLM 对每个 chunk 单独打相关性分（0 到 1），再次重新排序。重排效果最好，但每次都要调用 LLM，成本不低，因此只在 pro 计划的 quality profile 下开放。
