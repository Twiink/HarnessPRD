# 查询优化：同义词扩展与 LLM 改写

用户输入的原始 query 很少是检索友好的形式。"退货要收多少钱"和"退款手续费"说的是同一件事，但字面上几乎没有重叠。"怎么申请发票"和"发票申请流程"也是如此。如果直接拿原始 query 去检索，召回率会受到明显影响。

查询优化这一步的目标就是弥补这个差距：在不改变用户意图的前提下，让 query 覆盖更多相关的表述形式。rag-center 用两种手段组合完成这件事：同义词扩展和 LLM 改写。

## 同义词扩展

同义词扩展的思路很直觉：把"退款"和"退货"当作同义词，查询时自动把两个词都纳入检索范围。难点不在于这个思路本身，而在于**把同义词放在哪个阶段处理**。

一种做法是在索引阶段处理——文档写入时，把同义词展开并一起存入索引。这样检索速度快，但代价是一旦同义词表变了，所有文档都要重新索引。对于一个支持多租户、多知识库的平台，这个操作的代价非常大。

rag-center 选择了查询侧处理。同义词表存在 `knowledge_bases.settings` 的 JSONB 字段里，属于知识库级别的配置：

```json
// knowledge_bases.settings（JSONB 字段）

{
  "synonyms": {
    "退款": ["退款", "退货", "退订"],
    "发票": ["发票", "税票", "增值税发票"],
    "账户": ["账户", "账号", "用户账户"]
  }
}
```

查询发起时动态读取这张词表，命中的词扩展成所有变体，一起送入检索：

```python
# rag-center/app/services/query_optimizer.py

def expand_with_synonyms(query: str, synonyms: dict[str, list[str]]) -> list[str]:
    """将 query 中命中的词扩展为同义词变体，始终保留原始 query 作为兜底"""
    expanded = {query}
    for word, variants in synonyms.items():
        if word in query:
            for variant in variants:
                expanded.add(query.replace(word, variant))
    return list(expanded)
```

这样同义词表的变更立刻生效，不需要碰索引。不同知识库可以维护各自的同义词表，互不干扰。举个例子：知识库配置了 `退款 → [退款, 退货, 退订]` 这条规则，用户查"退款手续费"，系统会同时检索"退款手续费"、"退货手续费"、"退订手续费"三个变体，合并结果再送入后续流程。

## LLM 改写

同义词扩展靠的是预先配置的词表，覆盖范围有限。LLM 改写补充了词表覆盖不到的场景——那些需要理解语义才能做好的改写。

具体做法：把用户的原始 query 发给 LLM，附带一段提示，告诉它改写目标是生成更适合向量和关键词检索的表述。LLM 会去掉口语化表达、补充隐含的上下文、把一个问题拆分成多个检索意图：

```python
# rag-center/app/services/query_optimizer.py

REWRITE_PROMPT = """将用户问题改写为适合文档检索的形式。
要求：去掉口语化表达，补充隐含上下文，可拆分为多个检索意图。
参考同义词：{synonyms}

用户问题：{query}
改写结果（直接输出，不要解释）："""

async def rewrite_query(query: str, synonyms: dict) -> str:
    prompt = REWRITE_PROMPT.format(synonyms=synonyms, query=query)
    try:
        result = await asyncio.wait_for(
            llm_provider.complete(prompt),
            timeout=settings.QUERY_REWRITE_TIMEOUT_MS / 1000,
        )
        return result.strip()
    except asyncio.TimeoutError:
        return query  # 超时返回原始 query，不阻断主链路
```

比如用户询问"上次说的那个方案怎么收费"，这类有指代的问题，LLM 会识别出来，改写成"订阅方案价格 定价方式 收费标准"三个独立意图，覆盖面更广。

**LLM 改写不是替换，而是补充。** 改写结果和原始 query 会一起参与检索，即使改写偏差，原始 query 的召回结果也能兜底。

## 两者的协作顺序

同义词扩展先于 LLM 改写执行。先用同义词表得到一组候选词，再把这组候选词和原始 query 一起交给 LLM，让 LLM 在更完整的语义信息基础上做改写：

```
原始 query: "退款要多少钱"
    │
    ▼ 同义词扩展（知识库级别词表）
候选词: ["退款", "退货", "退订"]
    │
    ▼ LLM 改写（带候选词上下文）
search_query: "退款手续费 退货手续费 退款流程 退款政策"
    │
    ▼ 进入双路检索
```

最终送入双路检索的 `search_query` 是 LLM 改写的输出，同义词扩展的结果已经融入其中。这两个步骤都是可选的——如果知识库没有配置同义词表，扩展步骤跳过；如果当前 profile 不开启 LLM 改写，直接用原始 query。只有 quality profile 才会同时开启两者。

## 超时兜底的设计哲学

LLM 调用不稳定——网络抖动、模型服务超载都会造成延迟增加。如果 LLM 改写慢了，整条检索链路就被它拖住了，这是不可接受的。

rag-center 为 LLM 改写设置了 `QUERY_REWRITE_TIMEOUT_MS` 配置项。超时之后不报错、不等待，直接用原始 query 继续检索。用户感知到的只是这次检索没有经过改写，而不是请求失败。

这种设计体现了一个原则：**任何可选的优化环节，都不能成为主流程的单点故障**。LLM 改写是锦上添花，不是必需品。超时降级让它的失败代价降到最低。同样的逻辑在整条检索管道里反复出现，第五篇讲 Profile 时会再次看到这个模式。
