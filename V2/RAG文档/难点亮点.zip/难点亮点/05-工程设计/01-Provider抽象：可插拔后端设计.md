# Provider 抽象：可插拔后端设计

工程设计系列共三篇，分别从可扩展性、可维护性、可靠性三个维度讲解 rag-center 的核心工程决策。这是第一篇，聚焦可扩展性——如何让系统在 AI 生态快速演进的背景下，保持技术选型的灵活性。

## 为什么需要抽象

2024 年以来，embedding 模型的迭代速度几乎以月为单位。OpenAI 有 text-embedding-3，DeepSeek 有自己的 embedding，Ollama 可以本地跑各种开源模型。向量数据库这边也是群雄并起：pgvector、Qdrant、Weaviate、Milvus，每隔一段时间就有新的选手进来。

如果业务代码直接调用具体的库——比如直接 `import openai` 然后调用 `openai.embeddings.create()`——那每次换模型或换库，都要深入业务逻辑里去修改代码。这种耦合是隐性的技术债，平时不疼，换选型的时候才知道有多烧。

rag-center 的应对思路是为每一类外部依赖定义抽象层，具体实现藏在抽象后面，业务逻辑只和抽象打交道。

## 六类 Provider

系统定义了六类 Provider，覆盖从文档解析到检索排序的每个关键节点：

| Provider | 职责 | 当前实现 | 路径 |
|---------|------|---------|------|
| Embedding | 文本 → 向量 | OpenAI 兼容接口（支持 DeepSeek/Ollama） | `app/providers/embedding/` |
| Vector Store | 向量存储与相似度检索 | pgvector | `app/providers/vectorstores/` |
| Keyword Search | BM25 全文检索 | Elasticsearch + IK 分词 | `app/providers/keyword_search/` |
| LLM | 查询改写与条件生成 | OpenAI 兼容接口 | `app/providers/llm/` |
| Rerank | 候选文档重排序 | LLM 重排 / Noop 直通 | `app/providers/rerank/` |
| Document Parser | 原始文件 → 结构化文本 | 按格式分发：Markdown / PDF / Word / HTML | `app/providers/document_parser/` |

Embedding Provider 的 OpenAI 兼容接口意味着同一套代码可以对接 OpenAI、DeepSeek、Ollama，只需要改 base URL 和模型名。Document Parser Provider 把"格式识别和文本提取"从 indexing_service 里分离出来，让分块器始终只需要面对干净的文本输入，不关心原始文件是什么格式。

六类 Provider 覆盖了完整的处理链路，每一环都可以独立替换。接下来看抽象接口是如何设计的，以及 Rerank Provider 里一个值得单独讲的模式。

## 抽象基类的设计风格

每类 Provider 都有一个抽象基类，用 Python 的 `ABC` 和 `abstractmethod` 标注必须实现的接口。以 Embedding Provider 为例：

```python
# rag-center/app/providers/embedding/base.py

from abc import ABC, abstractmethod

class BaseEmbeddingProvider(ABC):

    @abstractmethod
    async def embed_documents(self, texts: list[str]) -> list[list[float]]:
        """批量将文本列表转为向量列表"""
        ...

    @abstractmethod
    async def embed_query(self, text: str) -> list[float]:
        """将单条查询文本转为向量"""
        ...
```

接口刻意设计得很窄。`embed_documents` 和 `embed_query` 分开，是因为很多模型对文档和查询有不同的处理方式，比如加前缀或用不同的 pooling 策略。把这个差异封在 Provider 内部，业务代码不需要知道。

Vector Store Provider 的接口同样简洁：

```python
# rag-center/app/providers/vectorstores/base.py

from abc import ABC, abstractmethod

class BaseVectorStoreProvider(ABC):

    @abstractmethod
    async def add_documents(
        self,
        collection_name: str,
        texts: list[str],
        vectors: list[list[float]],
        metadatas: list[dict] | None = None,
    ) -> list[str]:
        """向集合中写入文档，返回写入的文档 ID 列表"""
        ...

    @abstractmethod
    async def similarity_search(
        self,
        collection_name: str,
        query_vector: list[float],
        top_k: int,
    ) -> list[dict]:
        """按向量相似度检索，返回 top_k 个文档"""
        ...
```

接口不暴露任何 pgvector 特有的参数，比如索引类型、距离度量方式等。这些细节在具体实现里通过配置处理。上层业务代码感知到的只是"传入一个向量，得到 top_k 个文档"，实现从 pgvector 换成 Qdrant，调用侧零改动。

## noop Rerank 的设计

Rerank Provider 这里有个值得单独讲的设计：系统里有两个实现，一个是真正调 LLM 做重排的 `LLMRerankProvider`，另一个是 `NoopRerankProvider`。

`NoopRerankProvider` 的实现极其简单，就是把输入原封不动地返回：

```python
# rag-center/app/providers/rerank/noop.py

class NoopRerankProvider(BaseRerankProvider):

    async def rerank(
        self,
        query: str,
        documents: list[dict],
        top_k: int,
    ) -> list[dict]:
        # 直接透传，不做任何重排
        return documents[:top_k]
```

这个设计解决了一个实际问题：不是所有部署环境都有能力或预算跑 rerank 模型。如果把 rerank 写成硬依赖，那没有 rerank 的环境就无法启动系统。`NoopRerankProvider` 让 rerank 变成可选能力：有模型就用，没有就走直通，上游业务代码完全不需要处理这个条件分支。

这是抽象层设计的一个典型技巧——**用空实现来表达"不支持"，而不是用 null 或条件判断**。

## 切换实现只改配置

六类 Provider 都通过工厂函数初始化，工厂函数读取环境变量决定实例化哪个具体类。这个模式让"换后端"操作退化为改配置文件：

```python
# rag-center/app/providers/embedding/__init__.py

def get_embedding_provider() -> BaseEmbeddingProvider:
    provider_type = settings.EMBEDDING_PROVIDER
    if provider_type == "openai_compatible":
        return OpenAICompatibleEmbeddingProvider(
            base_url=settings.EMBEDDING_BASE_URL,
            api_key=settings.EMBEDDING_API_KEY,
            model=settings.EMBEDDING_MODEL,
        )
    raise ValueError(f"未知的 Embedding Provider 类型: {provider_type}")
```

想换 embedding 模型，改 `EMBEDDING_MODEL` 和 `EMBEDDING_BASE_URL` 即可，业务代码零改动。想接入一个新的向量库，只需要写一个继承 `BaseVectorStoreProvider` 的实现类，然后在工厂函数里加一个 `if` 分支。

## 小结

Provider 抽象的价值不在于当下，而在于它为未来的变化预留了空间。AI 基础设施的变化速度决定了这种抽象不是过度设计，而是必要的工程储备。六类 Provider 覆盖了从文件解析到结果排序的完整链路，任意一环的底层实现都可以独立替换，不影响其他部分。

下一篇讲错误码体系，从可扩展性转向可维护性，看系统如何让调用方能清晰感知每一种业务错误。
