# Markdown 感知分块：让每个 Chunk 都知道自己在哪里

上一篇讲了 rag-center 如何用 Celery 把文档处理从请求链路里分离出去。Celery worker 完成文件解析之后，下一步是分块。DocumentParser 负责把不同格式的原始文件转为结构化文本，分块则负责把这份文本切成可检索的 chunk。这一步看似简单，实则是检索质量好坏的关键所在。

## 朴素切块的问题

最直接的分块方式是按字符数截断，每隔 N 个字符切一刀，相邻 chunk 之间保留一定 overlap 防止信息断裂。rag-center 的 `app/utils/text_splitter.py` 实现的就是这种策略，用来处理纯文本格式的文档。

这种做法有其合理之处，简单可控，参数容易调。但对于结构化的技术文档，它会产生一个根本性的问题：**切刀不认识文档结构**。

以一篇有多个章节的产品手册为例。按字符数切，可能把"退款政策"这一节的开头和上一节"支付方式"的末尾拼在同一个 chunk 里——这个 chunk 在语义上混杂了两个主题，向量化之后的嵌入向量介于两者之间，对任何一个主题的检索都不是最优命中。

更严重的是表格。表格的每一行依赖表头才有意义，如果一张表格被从中间截断，后半部分的 chunk 里只有数据行，没有表头，完全失去了可解释性。

## Markdown 感知分块的核心思路

`app/utils/markdown_splitter.py` 实现了一套理解文档结构的分块策略，核心逻辑分两步走：

**第一步，按标题层级划分逻辑段落。** 解析 Markdown AST，把文档切成以标题为边界的逻辑块。`## 第三章` 下面的内容属于第三章，`### 退款政策` 下面的内容属于退款政策这一节。这样切出来的每个逻辑块，在主题上是内聚的。

**第二步，对超长逻辑块二次细切。** 一个逻辑块如果超过了 chunk_size 限制，再按字符数在块内部二次切分。这时候切的是同一个标题下的内容，语义领域是统一的，overlap 只会混合同一话题的相邻段落，不会跨章节污染。

```python
# rag-center/app/utils/markdown_splitter.py

class MarkdownSplitter:
    def split(self, text: str) -> list[Chunk]:
        sections = self._split_by_headings(text)
        chunks = []

        for section in sections:
            if len(section.content) <= self.chunk_size:
                chunks.append(Chunk(
                    content=section.content,
                    heading_path=section.heading_path,
                    chunk_type="text",
                ))
            else:
                # 超长逻辑块在同一标题域内二次细切，不会跨章节污染
                for sub_text in self.text_splitter.split(section.content):
                    chunks.append(Chunk(
                        content=sub_text,
                        heading_path=section.heading_path,
                        chunk_type="text",
                    ))

        return chunks

    def _split_by_headings(self, text: str) -> list[Section]:
        lines = text.split("\n")
        sections, current_lines = [], []
        current_headings: dict[int, str] = {}   # level → heading text

        for line in lines:
            match = re.match(r"^(#{1,6})\s+(.+)", line)
            if match:
                if current_lines:
                    sections.append(Section(
                        content="\n".join(current_lines).strip(),
                        heading_path=" > ".join(current_headings.values()),
                    ))
                    current_lines = []
                level = len(match.group(1))
                # 清除比当前层级深的标题，维护正确的路径链路
                current_headings = {k: v for k, v in current_headings.items() if k < level}
                current_headings[level] = match.group(2)
            else:
                current_lines.append(line)

        if current_lines:
            sections.append(Section(
                content="\n".join(current_lines).strip(),
                heading_path=" > ".join(current_headings.values()),
            ))
        return sections
```

两步结合，既保证了语义边界的清晰，又控制了每个 chunk 的长度不超过 embedding 模型的输入限制。

## heading_path：给每个 Chunk 定位

分块之后，每个 chunk 除了文本内容，还携带一条 **heading_path** 元数据，记录该 chunk 所处的标题层级路径，格式类似这样：

```
第三章 > 退款政策 > 线上退款
```

heading_path 由 `_split_by_headings` 在遍历标题时逐层维护，遇到同级或更高层级的新标题时自动截断旧路径，始终保持当前正确的层级链路。

这条元数据在检索时有两个用途：

- **辅助排序和过滤**：用户问"线上退款需要几天"，向量检索命中若干 chunk，可以用 heading_path 做后处理，优先展示路径里包含"退款"的 chunk，降低不相关章节混入结果的概率
- **生成引用来源**：LLM 回答时把 heading_path 拼接成"参考来源：第三章 > 退款政策 > 线上退款"，告诉用户这条信息来自哪里，比只给一段文本要可信得多

## 表格的特殊处理

表格是 Markdown 文档里最容易被切坏的结构。rag-center 对表格做了专门的处理：**表格不参与字符数切分，整张表格作为一个完整 chunk**，`chunk_type` 字段标注为 `table`，文本内容是保留了表头的完整 Markdown 表格。

这个决策背后有个权衡：表格 chunk 可能超过 chunk_size 的长度限制，embedding 模型需要截断才能处理。但相比切断表格导致数据失去关联，这个代价更可接受。实际的技术文档里，超长表格并不多见，大多数情况下表格整体嵌入的效果更好。

下面用一个简短的例子对比两种方案的差异。

**原始 Markdown 片段：**

```markdown
## 支付方式

目前支持三种支付方式：微信、支付宝和银行卡。

## 退款政策

### 线上退款

提交申请后，3-5 个工作日到账。

| 退款方式 | 到账时间 |
|--------|--------|
| 原路退回 | 3-5 工作日 |
| 余额退款 | 即时到账 |
```

**朴素切块（chunk_size=80）可能的结果：**

```
Chunk 1: "目前支持三种支付方式：微信、支付宝和银行卡。\n\n## 退款政策\n\n### 线上退款\n"
Chunk 2: "提交申请后，3-5 个工作日到账。\n\n| 退款方式 | 到账时间 |\n|--------|--------|\n"
Chunk 3: "| 原路退回 | 3-5 工作日 |\n| 余额退款 | 即时到账 |"
```

Chunk 1 混合了两个章节，Chunk 3 没有表头，语义都受损了。

**Markdown 感知分块的结果：**

```
Chunk 1: "目前支持三种支付方式：微信、支付宝和银行卡。"
  heading_path: "支付方式"
  chunk_type: text

Chunk 2: "提交申请后，3-5 个工作日到账。"
  heading_path: "退款政策 > 线上退款"
  chunk_type: text

Chunk 3: "| 退款方式 | 到账时间 |\n|--------|--------|\n| 原路退回 | 3-5 工作日 |\n| 余额退款 | 即时到账 |"
  heading_path: "退款政策 > 线上退款"
  chunk_type: table
```

每个 chunk 语义完整，定位清晰，表格保持了结构完整性。

## 对检索质量的影响

chunk 的质量直接决定 embedding 向量的质量。语义混杂的 chunk，其向量是多个话题的"平均值"，对每个话题的检索都不精准。语义内聚的 chunk，其向量集中在一个语义空间，命中率更高。

实际测试中，Markdown 感知分块在包含多章节结构的技术文档上，检索召回率明显优于朴素切块。代价是实现复杂度稍高，以及需要维护两套分块器。

分块质量影响的不只是检索，还会影响到重索引策略的设计。当分块参数需要调整时，如何让已入库的文档用上新参数？这是下一篇要讲的内容。
