# Plan 体系：分级功能与配额管控

数据隔离保证了租户之间互不干扰。但在一个 SaaS 平台里，除了"隔离"，还需要"区分"。不同付费级别的租户，应该享有不同的服务能力。这既是商业模型的基础，也是资源保护的必要手段。rag-center 的 Plan 体系就是用来解决这个问题的。

## 为什么需要 Plan 体系

先看资源保护这一侧。RAG 检索链路里各个环节的计算成本差异很大：

- **向量检索**：走近似最近邻索引，速度快、成本低，是基础能力
- **混合检索（hybrid）**：同时跑向量和 BM25 再做融合，成本翻倍
- **LLM 重排（rerank）**：调用额外的排序模型，时延和算力消耗明显更高
- **查询改写（rewrite）**：调用 LLM 对原始问题做扩写改写，引入大模型推理成本

如果对所有租户无差别开放这些能力，高成本功能会被免费用户消耗殆尽，影响整体服务稳定性。

再看商业模型这一侧。不同的租户愿意为不同程度的能力付费，提供分级服务既能给付费用户更好的体验，也能降低免费用户的获取门槛。Plan 体系是这两个目标的交点。

## 三档计划的设计逻辑

rag-center 设计了三个 Plan：free、standard、pro。

| 配额/能力 | free | standard | pro |
|-----------|------|----------|-----|
| 检索 QPS | 3 | 10 | 50 |
| 每日检索次数 | 500 | 5,000 | 100,000 |
| 最大知识库数 | 1 | 5 | 50 |
| 每库最大文档数 | 30 | 200 | 5,000 |
| 最大多知识库联检数 | 1 | 3 | 5 |
| 混合检索（hybrid） | ✗ | ✓ | ✓ |
| LLM 重排（rerank） | ✗ | ✗ | ✓ |
| 查询改写（rewrite） | ✗ | ✗ | ✓ |

三档的划分按照**功能成本和使用场景**分层，每个档位都有清晰的定位：

- **free**：只提供基础向量检索，能跑通完整 RAG 流程，但资源上限很低，高成本功能全部关闭。适合评估和小规模试用。
- **standard**：放开混合检索。hybrid 的召回质量比纯向量更好，是大多数生产场景的合理选择，资源上限也随之提升。
- **pro**：才开放 rerank 和 rewrite。这两个功能需要额外调用模型，成本显著更高但效果最好，面向数据量大、对检索质量要求高的场景。

## Plan 配置硬编码在代码里

Plan 的配置保存在 `app/tenant/plan_presets.py` 里，直接以数据类的形式写死，没有存在数据库里：

```python
# rag-center/app/tenant/plan_presets.py

from dataclasses import dataclass

@dataclass(frozen=True)
class PlanConfig:
    max_qps: int
    daily_retrieval_limit: int
    max_knowledge_bases: int
    max_docs_per_kb: int
    max_multi_kb: int
    allow_hybrid: bool
    allow_rerank: bool
    allow_rewrite: bool

PLAN_PRESETS: dict[str, PlanConfig] = {
    "free": PlanConfig(
        max_qps=3,
        daily_retrieval_limit=500,
        max_knowledge_bases=1,
        max_docs_per_kb=30,
        max_multi_kb=1,
        allow_hybrid=False,
        allow_rerank=False,
        allow_rewrite=False,
    ),
    "standard": PlanConfig(
        max_qps=10,
        daily_retrieval_limit=5000,
        max_knowledge_bases=5,
        max_docs_per_kb=200,
        max_multi_kb=3,
        allow_hybrid=True,
        allow_rerank=False,
        allow_rewrite=False,
    ),
    "pro": PlanConfig(
        max_qps=50,
        daily_retrieval_limit=100000,
        max_knowledge_bases=50,
        max_docs_per_kb=5000,
        max_multi_kb=5,
        allow_hybrid=True,
        allow_rerank=True,
        allow_rewrite=True,
    ),
}
```

这个选择是有意为之的。Plan 配置是平台级别的业务策略，它的变更应该和代码变更一样，走 code review、版本控制、测试、上线的完整流程。如果存在数据库里，任何有数据库权限的人都可以直接修改配额，既没有审计，也没有回滚，出问题了很难追溯。

**版本可控、不怕误改、部署时即生效**，是硬编码配置最核心的优势。代价是调整 Plan 需要走部署流程，不能热生效。这对 rag-center 来说完全可以接受：Plan 配置变更频率很低，不值得为了热更新引入额外的复杂度。

## 配额执行的两个维度

Plan 约束的执行分两个维度：**功能开关**和**资源上限**，两者职责明确，分属不同模块。

**功能开关**决定"能不能用"，由 `retrieve_policy.py` 负责。当一个 free 租户发来指定 `mode=hybrid` 的检索请求时，系统会拦截并返回明确的错误：

```python
# rag-center/app/services/retrieve_policy.py

class RetrievePolicy:
    def validate(self, params: RetrieveParams, plan: PlanConfig) -> None:
        if params.mode == "hybrid" and not plan.allow_hybrid:
            raise PlanFeatureNotAllowed(
                feature="hybrid",
                message="混合检索需要 standard 及以上计划",
            )
        if params.rerank and not plan.allow_rerank:
            raise PlanFeatureNotAllowed(
                feature="rerank",
                message="LLM 重排需要 pro 计划",
            )
        if params.rewrite and not plan.allow_rewrite:
            raise PlanFeatureNotAllowed(
                feature="rewrite",
                message="查询改写需要 pro 计划",
            )
```

**资源上限**决定"能用多少"，由 `quota_service.py` 负责，在检索调用链入口处做校验：

```python
# rag-center/app/services/quota_service.py

class QuotaService:
    async def check_and_consume(self, tenant_id: str, plan: PlanConfig) -> None:
        # 日次数校验
        daily_key = f"quota:daily:{tenant_id}:{today()}"
        daily_count = int(await self.redis.get(daily_key) or 0)
        if daily_count >= plan.daily_retrieval_limit:
            raise QuotaExceeded(code="DAILY_LIMIT_EXCEEDED")

        # QPS 校验（滑动窗口计数）
        current_qps = await self._sliding_window_qps(tenant_id)
        if current_qps >= plan.max_qps:
            raise QuotaExceeded(code="QPS_LIMIT_EXCEEDED")

        # 校验通过，消耗配额
        await self.redis.incr(daily_key)
        await self.redis.expire(daily_key, 86400)
```

调用链里的顺序是先跑资源校验（`quota_service`），再跑能力校验（`retrieve_policy`）。`quota_service` 管资源，`retrieve_policy` 管能力，修改其中一个不影响另一个。

## 超出上限时的行为

约束只有在有明确反馈的情况下才有意义。rag-center 对 Plan 约束的违规都返回具体的错误码，而不是笼统的 500 错误：

| 场景 | 错误码 | HTTP 状态 |
|------|--------|-----------|
| 日检索次数超限 | `DAILY_LIMIT_EXCEEDED` | 429 |
| QPS 超限 | `QPS_LIMIT_EXCEEDED` | 429 |
| 功能当前 Plan 不支持 | `PLAN_FEATURE_NOT_ALLOWED` | 403 |
| 知识库数量超限 | `KB_QUOTA_EXCEEDED` | 403 |

调用方可以根据错误码做出相应处理——比如 429 时做重试退避，403 时告知用户升级 Plan 或做本地降级逻辑。这也是平台设计里常被忽视的一点：**错误信息是 API 契约的一部分**。明确的错误码和错误描述，让 Plan 体系对调用方来说是透明的、可预期的，而不是一个黑盒。

---

至此，鉴权、隔离、分级三个层次共同构成了 rag-center 多租户平台的核心设计。鉴权确认身份，隔离保护数据，分级区分服务，三层相互配合，支撑起一个可以同时服务多个租户的 RAG 基础设施。
