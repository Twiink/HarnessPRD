# API Key 安全设计

rag-center 是一个面向多租户的 RAG 服务平台。每个接入方都是一个独立租户，通过 API 调用检索、问答等能力。第一道门是鉴权。

鉴权方案的选型不是随意的。常见方案有三种：

1. **Session 登录态**：依赖服务端存储登录状态，不适合无状态的 API 网关场景。
2. **JWT Token**：可以做无状态鉴权，但吊销成本高，一旦签发就很难在过期前强制失效。
3. **API Key**：无需服务端维护登录态，也能精确控制生命周期，对服务与服务之间的调用场景天然友好。

rag-center 的消费方是后端服务，不是浏览器用户，API Key 是最合适的选择。

## Key 的格式与生成

Key 采用固定前缀加随机串的格式：

```
rk_live_<32位随机十六进制>
```

前缀 `rk_live_` 有两个作用：一是在日志或错误信息里能一眼辨认这是 rag-center 的 Key，而不是其他系统的凭证；二是方便 secret scanning 工具（比如 GitHub 内置的检测）识别泄露的 Key。固定前缀是业界常见做法，Stripe、OpenAI 的 Key 都有类似设计。

32 位十六进制的随机部分由密码学安全的随机数生成器产生，熵值足够高，不存在碰撞或穷举的实际威胁。生成逻辑如下：

```python
# rag-center/app/core/auth.py

import secrets
import hashlib

def generate_api_key() -> tuple[str, str, str]:
    """返回 (明文 key, sha256 哈希, 日志用 prefix)"""
    raw = secrets.token_hex(16)           # 32 位十六进制随机串
    key = f"rk_live_{raw}"
    key_hash = hashlib.sha256(key.encode()).hexdigest()
    key_prefix = key[:12]                 # 取前 12 位用于日志标识
    return key, key_hash, key_prefix
```

Key 生成后只返回一次明文，后续入库存储的是哈希值和前缀，明文永远不落地。

## 明文不入库

这是整个鉴权设计里最核心的一条原则。

Key 被创建出来之后，系统**只打印一次明文**，告知用户保存好。此后，数据库里永远不会存储这个明文串，存的只是它的 SHA-256 哈希值。

鉴权时，系统从请求头里拿到 Bearer Token，先做一次 SHA-256，再拿计算结果去数据库里查：

```
请求头: Authorization: Bearer rk_live_abcd1234...
                          │
                     SHA-256 哈希
                          │
                    查数据库比对
                          │
               校验: active=true & 未过期 & 租户未禁用
                          │
                    注入 TenantContext
```

这和密码存储的思路一样，区别是 API Key 不需要加盐——Key 本身的随机性已经足够高，不存在彩虹表攻击的空间。即使数据库被完整拖走，攻击者拿到的也只是哈希值，无法反推出原始 Key，无法冒用任何租户的身份。

## key_prefix 的工程价值

完整 Key 只有用户自己知道，但服务侧需要一种方法，在不暴露 Key 的前提下，在日志里标记"这次请求用的是哪把 Key"。

解决方法是 **key_prefix**。创建 Key 时，系统取明文的前 12 位存入数据库（如 `rk_live_abcd`），日志里记录的是 prefix，而不是完整 Key：

```python
# rag-center/app/core/middleware.py

logger.info(
    "retrieval request received",
    tenant_id=api_key_record.tenant_id,
    key_prefix=api_key_record.key_prefix,   # 只记录前缀，不记录完整 Key
)
```

这样运维人员看到日志里的 prefix，就能和数据库里的 Key 记录对应上，方便排查是哪个租户的哪把 Key 在请求，也方便快速定位和吊销。12 位 prefix 暴露的信息量极小，对 Key 的安全性几乎没有影响。

## AUTH_ENABLED 开关

生产环境需要强鉴权，但本地开发阶段频繁生成 Key、配置环境会拖慢节奏。rag-center 提供了环境变量 `AUTH_ENABLED`，设为 `false` 时鉴权中间件直接放行，跳过所有 Key 校验：

```python
# rag-center/app/core/middleware.py

class AuthMiddleware:
    async def __call__(self, request: Request, call_next):
        if not settings.AUTH_ENABLED:
            # 本地开发：注入一个固定的开发租户，跳过鉴权
            request.state.tenant = TenantContext(tenant_id="dev", plan="pro")
            return await call_next(request)

        token = self._extract_bearer(request)
        if not token:
            return JSONResponse(status_code=401, content={"error": "missing token"})

        key_hash = hashlib.sha256(token.encode()).hexdigest()
        api_key = await self.key_repo.get_by_hash(key_hash)
        if not api_key or not api_key.is_valid():
            return JSONResponse(status_code=401, content={"error": "invalid key"})

        request.state.tenant = TenantContext(
            tenant_id=api_key.tenant_id,
            plan=api_key.plan,
        )
        return await call_next(request)
```

设计思路是：**安全策略和开发体验可以分开配置**，而不是用一套硬编码逻辑同时服务两种场景。生产部署时环境变量默认开启鉴权，CI 和本地开发可以关掉以减少摩擦。这类问题的防线不在代码里，而在部署流程和环境变量管理上——只要生产环境的配置管理规范，`AUTH_ENABLED=false` 就不会出现在生产机器上。

## 鉴权之后

鉴权成功后，系统把当前租户的信息注入 **TenantContext**，后续所有业务逻辑都从这里取 `tenant_id`，不再重复解析请求头：

```python
# rag-center/app/services/retrieve_service.py

# 在任意业务层直接从 request.state 取，不再关心 Token 是什么
tenant: TenantContext = request.state.tenant
knowledge_bases = await kb_repo.list_by_tenant(tenant.tenant_id)
```

这是一个典型的依赖注入模式：鉴权层负责"你是谁"，业务层负责"你能做什么"，职责清晰，互不耦合。

知道"谁在访问"只是第一步。下一个问题是：多个租户共用同一套数据库，如何确保他们彼此看不到对方的数据？这就是数据隔离要解决的问题。
