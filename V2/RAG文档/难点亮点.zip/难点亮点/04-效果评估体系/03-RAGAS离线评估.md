# RAGAS 离线评估

在线日志和 Langfuse 追踪能帮你发现问题、定位问题，但它们都是面向个案的。当你问"系统整体的检索质量处于什么水平"，或者"调整了 chunk_size 之后效果有没有提升"，个案分析就不够用了。你需要在一批标准测试用例上运行评估，得到可以横向对比的量化分数。

rag-center 使用 [RAGAS](https://docs.ragas.io) 做离线评估。RAGAS 是专为 RAG 系统设计的评估框架，提供了一套针对检索和生成两个阶段的标准化指标。rag-center 目前主要用它来评估检索阶段，关注两个核心指标：**context_precision** 和 **context_recall**。

## 两个指标各自衡量什么

这两个指标从不同角度衡量检索质量，各有侧重：

**context_precision** 衡量的是"返回的有没有噪音"。在系统召回的所有 chunk 里，真正和问题相关的占多少比例。如果召回了 10 个 chunk，其中只有 3 个是真正有用的，precision 就是 0.3。这个指标低，说明系统引入了太多无关内容——LLM 在生成回答时需要从大量噪音里找有用信息，容易出错。

**context_recall** 衡量的是"该找到的有没有漏"。在所有真正相关的内容里，系统实际召回了多少。如果标准答案涉及 5 段关键内容，但系统只找到了 3 段，recall 就是 0.6。这个指标低，说明系统遗漏了重要信息——LLM 缺少足够的上下文，生成的回答会不完整。

两个指标往往有一定的张力：增大 top_k 能提高 recall，但也会引入更多噪音，拉低 precision。评估的价值就在于帮你找到合理的平衡点，而不是凭感觉调参。

要计算这两个指标，首先需要构建一个评估集——它是整套评估体系的数据基础。

## 评估集的构建

离线评估需要一个评估集，格式是三元组：

```
<问题, 标准答案, 相关文档片段列表>
```

每个三元组表示：对于这个问题，正确答案是什么，知识库里哪些 chunk 是真正相关的。有了这个"标准答案"，才能计算 precision 和 recall。

构建评估集有两条路：

1. **从低分反馈里筛**：前面两篇提到，用户反馈的 1–2 分记录是问题信号的集中地。把这些低分对应的 query 从日志里导出，再到 Langfuse 里查对应的 trace，看系统当时召回了什么，再由人工判断"哪些 chunk 是真正相关的"，形成标注。这条路的好处是评估集直接来自真实问题，针对性强。

2. **主动标注**：从知识库里选出有代表性的文档，针对每篇文档设计 3–5 个问题，人工标注相关 chunk。这条路的好处是覆盖面更广，不只覆盖"历史上出过问题的 query"。

实际操作中，两条路通常结合使用：低分反馈构建的评估集用来做回归测试，确保已知问题不再复现；主动标注的评估集用来做整体基准测试。

## 从 Langfuse 导出数据

Langfuse 支持通过 API 导出 trace。下面是一个简化的导出脚本，用于把低分 trace 提取成评估集格式：

```python
# rag-center/scripts/export_low_score_traces.py

from langfuse import Langfuse

client = Langfuse()

traces = client.get_traces(
    name="rag_retrieve",
    tags=["low_score"],
    limit=200,
)

eval_dataset = []
for trace in traces:
    query = trace.input.get("query")
    retrieved_chunks = trace.output.get("chunks", [])
    eval_dataset.append({
        "question": query,
        "retrieved_contexts": [c["text"] for c in retrieved_chunks],
        # ground_truth 和 ground_truth_context 需要人工补充
    })
```

导出之后，需要人工对每条记录补充 `ground_truth`（标准答案）和 `ground_truth_context`（真正相关的 chunk 列表）。这一步无法完全自动化，但通过低分 trace 已经缩小了需要标注的范围。

## 运行评估

评估集准备好之后，用 RAGAS 计算指标的过程比较直接：

```python
# rag-center/scripts/run_ragas_eval.py

from ragas import evaluate
from ragas.metrics import context_precision, context_recall
from datasets import Dataset

data = {
    "question":     ["退款手续费是多少？", "..."],
    "answer":       ["...", "..."],           # LLM 生成的回答（或检索结果摘要）
    "contexts":     [["chunk_a", "chunk_b"], ["..."]],  # 系统召回的 chunk 列表
    "ground_truth": ["退款手续费为 0 元", "..."],       # 标准答案
}

dataset = Dataset.from_dict(data)
result = evaluate(dataset, metrics=[context_precision, context_recall])

# 整体均值
print(result)

# 明细：找出哪些 query 得分偏低
df = result.to_pandas()
print(df[["question", "context_precision", "context_recall"]]
      .sort_values("context_precision"))
```

运行后，终端输出大致如下：

```
Evaluating: 100%|████████████| 50/50 [02:14<00:00,  2.68s/it]

{'context_precision': 0.7320, 'context_recall': 0.6140}

                    question  context_precision  context_recall
    上次说的那个方案怎么收费              0.20            0.80
          合同模板在哪里下载              0.33            1.00
            发票申请需要几天              0.50            0.50
            退款手续费是多少              1.00            1.00
        如何添加知识库管理员              1.00            0.80
```

前两行均值给出整体基准，明细表按 precision 升序排列，问题最大的 query 浮在最上面。"上次说的那个方案怎么收费"precision=0.20 但 recall=0.80，典型的"召回了，但大部分不相关"——指向 LLM 改写引入了过多噪音，或 top_k 设置偏大；"合同模板在哪里下载"precision=0.33 但 recall 达到 1.00，说明相关内容全都找到了，只是混入了不少无关 chunk，开启 rerank 通常能解决。

## 评估结果如何指导优化

数字本身不是目的，读懂数字背后的含义才能做有效优化：

| 问题现象 | 可能原因 | 优化方向 |
|---------|---------|---------|
| precision 偏低 | chunk 切得太碎，召回了太多"沾边但不相关"的内容 | 增大 `chunk_size`，让每个 chunk 包含更完整的上下文 |
| precision 偏低 | 未开启 rerank，候选里噪音过多 | 开启 rerank 做二次过滤 |
| recall 偏低 | 用词差异导致相关内容未被召回 | 完善同义词表，或增大 `top_k` |
| 两者同时偏低 | profile 选择不当，如语义场景用了精确匹配 profile | 对比不同 profile 下的分数，选对配置 |

调整参数时，precision 和 recall 往往会此消彼长，评估集的价值正在于此——让你看到每次调整对两个指标的实际影响，而不是凭感觉猜。

## 评估是持续过程

RAGAS 评估不是一次性任务。每次对检索配置做调整——改 chunk_size、换 profile、调同义词表——都应该在评估集上重新跑一遍，对比调整前后的分数。这样可以确认优化方向是对的，也能避免"调了一个指标、另一个指标悄悄下降"的情况。

配合前两篇建立的在线日志和 Langfuse 追踪，rag-center 形成了一个完整的评估闭环：在线数据采集问题信号，Langfuse 定位具体 trace 的问题所在，RAGAS 量化整体效果并验证优化结果。三个层次各有侧重，共同支撑检索质量的持续改进。
